
export default function Checkout() {
  return (
    <div className="min-h-screen bg-[#0D0D0D] text-[#E5E5E5] p-6">
      <h1 className="text-3xl font-bold text-[#0F4C81] mb-6">Checkout</h1>
      <form className="space-y-4 max-w-md mx-auto">
        <input type="text" placeholder="Full Name" className="w-full p-3 rounded-xl bg-[#1A1A1A] text-white" />
        <input type="text" placeholder="Phone Number" className="w-full p-3 rounded-xl bg-[#1A1A1A] text-white" />
        <input type="text" placeholder="Delivery Address" className="w-full p-3 rounded-xl bg-[#1A1A1A] text-white" />
        <select className="w-full p-3 rounded-xl bg-[#1A1A1A] text-white">
          <option>Easypaisa</option>
          <option>JazzCash</option>
          <option>Bank Transfer</option>
        </select>
        <button className="w-full p-3 bg-[#0F4C81] text-white rounded-xl hover:bg-[#FF007F]">Place Order</button>
      </form>
    </div>
  );
}
