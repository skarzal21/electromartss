
export default function AdminDashboard() {
  return (
    <div className="min-h-screen bg-[#0D0D0D] text-[#E5E5E5] p-6">
      <h1 className="text-3xl font-bold text-[#0F4C81] mb-6">Admin Dashboard</h1>
      <div className="space-y-4 max-w-md mx-auto">
        <button className="w-full p-3 bg-[#0F4C81] text-white rounded-xl hover:bg-[#FF007F]">Add New Product</button>
        <button className="w-full p-3 bg-[#0F4C81] text-white rounded-xl hover:bg-[#FF007F]">Manage Orders</button>
        <button className="w-full p-3 bg-[#0F4C81] text-white rounded-xl hover:bg-[#FF007F]">View Payments</button>
      </div>
    </div>
  );
}
