
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { motion } from "framer-motion";
import { ShoppingCart, Smartphone, Monitor, Headphones } from "lucide-react";

export default function HomePage() {
  const [products] = useState([
    { id: 1, name: "Gaming Laptop", price: 250000, icon: <Monitor size={40} /> },
    { id: 2, name: "Smartphone", price: 120000, icon: <Smartphone size={40} /> },
    { id: 3, name: "Bluetooth Headphones", price: 8500, icon: <Headphones size={40} /> },
  ]);

  return (
    <div className="min-h-screen bg-[#0D0D0D] text-[#E5E5E5] p-6">
      <header className="text-center mb-10">
        <h1 className="text-4xl font-bold text-[#0F4C81]">ElectroMart</h1>
        <p className="text-[#FF007F]">Next-Gen Electronics Store for Pakistan</p>
      </header>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1 }}
        className="grid md:grid-cols-3 gap-6"
      >
        {products.map((product) => (
          <Card
            key={product.id}
            className="bg-[#1A1A1A] border border-[#0F4C81] rounded-2xl shadow-lg p-4 hover:scale-105 transition-all"
          >
            <CardContent className="flex flex-col items-center">
              <div className="text-[#FF007F] mb-4">{product.icon}</div>
              <h2 className="text-xl font-semibold mb-2">{product.name}</h2>
              <p className="mb-4">PKR {product.price.toLocaleString()}</p>
              <Button className="bg-[#0F4C81] hover:bg-[#FF007F] text-white w-full">
                <ShoppingCart className="mr-2" size={18} /> Buy Now
              </Button>
            </CardContent>
          </Card>
        ))}
      </motion.div>

      <div className="mt-10 text-center text-sm text-gray-500">
        <p>Payments: Easypaisa | JazzCash | Bank Transfer</p>
        <p>© 2025 ElectroMart Pakistan</p>
      </div>
    </div>
  );
}
