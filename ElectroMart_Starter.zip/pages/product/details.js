
export default function ProductDetails() {
  return (
    <div className="min-h-screen bg-[#0D0D0D] text-[#E5E5E5] p-6">
      <h1 className="text-3xl font-bold text-[#0F4C81] mb-4">Product Details</h1>
      <div className="bg-[#1A1A1A] rounded-xl p-6 shadow-lg">
        <h2 className="text-2xl font-semibold mb-2 text-[#FF007F]">Gaming Laptop</h2>
        <p className="mb-4">High performance gaming laptop with RTX graphics.</p>
        <p className="text-lg mb-4">Price: PKR 250,000</p>
        <button className="p-3 bg-[#0F4C81] text-white rounded-xl hover:bg-[#FF007F]">Buy Now</button>
      </div>
    </div>
  );
}
