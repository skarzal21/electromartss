module.exports = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx}",
    "./components/**/*.{js,ts,jsx,tsx}"
  ],
  theme: {
    extend: {
      colors: {
        primary: '#1E1B4B',
        secondary: '#DB2777'
      },
      borderRadius: {
        xl: '1.5rem',
        '2xl': '2rem'
      }
    },
  },
  plugins: [],
}